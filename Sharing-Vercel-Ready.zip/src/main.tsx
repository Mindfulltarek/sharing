import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles.css';
import './overrides.css';
import './landing-theme.css';
import './workspace-theme.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
